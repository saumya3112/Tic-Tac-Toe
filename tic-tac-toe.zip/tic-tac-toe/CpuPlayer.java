/**
 * A computer-controlled Tic-tac-toe player that implements a random playing strategy.
 *
 * @author Saumya Arya
 * @version CS102
 * @field game the game the player is playing
 * @field symbol character to represent the player's moves on the board
 */
public class CpuPlayer extends APlayer{
    /** 
     * constructor for objects of class CpuPlayer.
     * @param game the tic-tac-toe game that is to be played
     * @param symbol the character symbol to be used to represent this player's moves
     **/
    CpuPlayer(Game game, char symbol){
        this.game=game;
        this.symbol=symbol;
    }

    /**
     * Checks if human can win in next move. if tgey can, computer prevents it. Otherwise
     * Picks a move uniformly at random. It does this by generating random moves within the game board boundaries until it finds an unnocupied position. Assumes the game isn't over yet, otherwise it'd go into an infinite loop.
     * @return the chosen move
     */
    public Move pickMove(){
        int row=0;
        int col=0;
        Move move;

        int boardSize= game.getBoardSize();
        int counter=0;
        char board[][]= game.getBoard();
        boolean m=true;

        do {
            for (int i=0; i<boardSize; i++){
                counter=0;
                for (int j=0; j<boardSize;j++){
                    if (board[i][j] == 'X'){
                        counter++;
                        if (counter== boardSize-1){
                            for (j=0; j<boardSize;j++){
                                if(board[i][j]==' '){
                                    row=i;
                                    col=j;
                                    m=false;

                                }
                            }}}}} //checks human winning in a row

            for (int j=0; j<boardSize; j++){
                counter=0;
                for (int i=0; i<boardSize; i++){
                    if (board[i][j] == 'X'){
                        counter++;
                        if (counter== boardSize-1){
                            for (i=0; i<boardSize;i++){
                                if(board[i][j]==' '){
                                    row=i;
                                    col=j;
                                    m=false;

                                }
                            }}}}} //checks human winning in a col
            counter=0;
            for (int j=0; j<boardSize; j++){
                for (int i=0; i<boardSize; i++){
                    if(i==j && board[i][j]=='X'){
                        counter++;
                        if (counter== boardSize-1){
                            for(i=0; i<boardSize; i++){
                                for (j=0; j<boardSize;j++){
                                    if(i==j && board[i][j]==' '){
                                        row=i;
                                        col=j;
                                        m=false;

                                    }
                                }
                            }
                        }
                    }
                }
            } //checks human winning in forward diagonal
            for (int i=0; i<boardSize; i++){
                counter=0;
                for (int j=0; j<boardSize;j++){
                    if (board[i][j] == 'O'){
                        counter++;
                        if (counter== boardSize-1){
                            for (j=0; j<boardSize;j++){
                                if(board[i][j]==' '){
                                    row=i;
                                    col=j;
                                    m=false;

                                }
                            }}}}} //checks if cpu will win next move in a row
            for (int j=0; j<boardSize; j++){
                counter=0;
                for (int i=0; i<boardSize; i++){
                    if (board[i][j] == 'O'){
                        counter++;
                        if (counter== boardSize-1){
                            for (i=0; i<boardSize;i++){
                                if(board[i][j]==' '){
                                    row=i;
                                    col=j;
                                    m=false;

                                }
                            }}}}} //checkS Comp winning in a col
            for (int j=0; j<boardSize; j++){
                for (int i=0; i<boardSize; i++){
                    if(i==j && board[i][j]=='O'){
                        counter++;
                        if (counter== boardSize-1){
                            for(i=0; i<boardSize; i++){
                                for (j=0; j<boardSize;j++){
                                    if(i==j && board[i][j]==' '){
                                        row=i;
                                        col=j;
                                        m=false;

                                    }
                                }
                            }
                        }
                    }
                }
            } //checks comp winning in forward diagonal

            if(m){
                row = (int) (Math.random()*game.getBoardSize());
                col = (int) (Math.random()*game.getBoardSize());
            }
            move= new Move(row, col);
            if(game.isValidMove(move) == 'V')
                return move;
        }
        while(game.isValidMove(move) != 'V');
        return move;
    }

}

