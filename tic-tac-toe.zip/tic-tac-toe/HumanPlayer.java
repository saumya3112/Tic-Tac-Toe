/**
 * A human Tic-tac-toe player that reads moves from the keyboard.
 * @author Saumya Arya
 * @version CS102

 */
import java.util.Scanner;

public class HumanPlayer extends APlayer
{
    /** 
     * constructor for objects of class HumanPlayer.
     * @param game the tic-tac-toe game that is to be played
     * @param symbol the character symbol to be used to represent this player's moves
     **/
    HumanPlayer(Game game, char symbol){
        this.game= game;
        this.symbol = symbol;
    }

    /**
     * This method asks the user to pick a tic-tac-toe move. Moves are read from the keyboard and are specified by two characters rc, where r is a letter representing the row and c is a digit representing the column. For instance a1 means the 1st column of the first row and c2 means the 2nd column of the 3rd row. If the user specifies: a position that is outside the bound of the game board or, a position that is already occupied, an appropriate error message is shown and the user is asked for another position. If the user writes quit (regardless of case), the method returns null, signifying that the program should terminate.
     * @return a move the player chose or null if player wants to quit
     */

    public Move pickMove(){
        System.out.println("Please input move in RC format");

        Scanner inputMove = new Scanner(System.in);
        Move move;
        do{
            String input = inputMove.next();
            input = input.toUpperCase();
            if (input.equals("QUIT")){
                return null;
            }
            if (input.length() != 2){
                System.out.println("Please input move in correct format of RC");
            }
            if (input.length() == 2){
                rowc= input.charAt(0);  
                colc= input.charAt(1);
            }

            row = (int)rowc - 65;
            col = (int)colc - 49;

            move= new Move(row, col);
            if (game.isValidMove(move) == 'V'){
                return move;
            }
            if (game.isValidMove(move) == 'R'){
                System.out.println("Row is invalid");
            }
            if (game.isValidMove(move) == 'C'){
                System.out.println("Column is invalid");
            }
            if (game.isValidMove(move) == 'O'){
                System.out.println("Position is occupied");
            }
        } while (game.isValidMove(move) != 'V');
        System.out.println(game);
        game.executeMove(move, symbol);
        return move;
    }

}

