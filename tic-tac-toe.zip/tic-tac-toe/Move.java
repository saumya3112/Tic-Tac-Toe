
/**
 * Class that represents a move
 * @author Saumya Arya
 * @field row the row
 * @field col the column
 */
public class Move{
    int col;
    int row;
    /**
     * Constructor for a move, initiates row and column
     * @param row the row inputted
     * @param col the column inputted
     *
     */

    Move(int row, int col){
        this.row=row;
        this.col=col;
    }
}
