  /**
 * Class to get and define the stats of every game
 *
 * @author Saumya
 * @field nlosses number of losses by human player
 * @field nties number of times game ended in tie
 * @field nwins number of wins for human player
 */
public class GameStats{
	//the losses
	private int nlosses;
	//ties
	private int nties;
	//wins
	private int nwins;
 /**
 * Constructer for GameStats, set wins, ties, and losses to 0
 
 */
	public GameStats(){
    	//initiates all three to zero
    	this.nwins = 0;
    	this.nties = 0;
    	this.nlosses = 0;
	}
 /**
 *increments number of human wins
 */
	//adds one to win counter
	public void recordWin(){
    	nwins = nwins + 1;
	}
 	/**
 * increments nties
 */
	//adds one to tie
	public void recordTie(){
    	nties = nties + 1;
	}
 	/**
 * Adds 1 to nlosses
 */
	//adds one to loss
	public void recordLoss(){
    	nlosses = nlosses + 1;
	}
	/**
 * Returns a textual representation of the statistics contained in this object.
 * @returns a textual representation of the statistics contained in this object
 *
 *
 */
	//turns the wins losses and ties into a string organizing the three
	public String toString(){
    	String stats = new String("");
    	stats = stats + "Win  Loss  Tie" + "\n" + nwins + "	" + nlosses + "  	" + nties;
    	return stats;
	}
}
