/**
 * A human Tic-tac-toe player that reads moves from the keyboard.
 * @author Saumya Arya
 * @version CS102
 * @field board represents the game board as matrix of player symbols
 * @field boardSize represents board size, which will be a boardSize x boardSize matrix
 * @field players represents the game board as matrix of player symbols
 * @field SYMBOL_BLANK the character to be used to represent a blank space on the board (' ')
 * @fieldnSYMBOL_CPU the character to be used to represent a cpu move on the board ('O')
 * @field SYMBOL_HUMAN the character to be used to represent a human move on the board ('X')
 */
import java.util.Scanner;
public class Game
{
    private char[][] board;
    private int boardSize;
    private APlayer[] players  = new APlayer[2];
    private char SYMBOL_BLANK = ' ';
    private char SYMBOL_CPU = 'O';
    private char SYMBOL_HUMAN = 'X' ;
    char symbol;
    /** 
     * constructor for objects of class Game.
     **/
    public int getBoardSize(){
        return boardSize;
    }
    public char[][] getBoard(){
        return board;
    }

    /** 
     * constructor for objects of class Game.
     * @param boardSize the game board size, which will be a boardSize x boardSize matrix
     **/
    public Game(int boardSize){
        this.boardSize = boardSize;  //initialize boardSize
        board = new char[boardSize][boardSize]; //initialise board
        for (int i = 0; i < boardSize; i++){
            for( int j = 0; j<boardSize; j++){
                board[i][j] = SYMBOL_BLANK;
            }
        }

    }

    /**
     * Validates a potential move. Returns 'V' if the move is valid, or a different character indicating the reason why the move is invalid.
     * @param move the move to be validated
     * @return 'V' is move is valid, 'R' if it specifies an invalid row, 'C' if it specifies an invalid column, or 'O' if it refers to an already-occupied position
     */
    public char isValidMove​(Move move){
        if (move.row > boardSize-1)
            return 'R';
        if (move.col > boardSize-1)
            return 'C';
        if (board[move.row][move.col]  == SYMBOL_BLANK)
            return 'V';
        else    
            return 'O';
    }

    /**
     * Executes the move passed as an argument. If the move is invalid it returns false.
     * @param move the move to be validated
     * @param symbol  the symbol of the player who is making the move
     * @return true if the move was successfully executed
     */
    protected boolean executeMove​(Move move,char symbol){
        if (isValidMove(move) == ('V')){
            this.board[move.row][move.col] = symbol;
            return true;
        }
        else{
            return false;
        }
    }

    /**
     * A method that analyzes the board to determine the current game sate, which is then returned as a character. A game is over if either player has completed a row, a line, or a diagonal. Moreover, a game is also over if the board is full, even if no player completed a row, line, or diagonal. That indicates a tie situation.
     * @return A character indicating the game state: '?' if the game isn't over yet, 'T' if the game is over and tied, or, if a player won, the winning player's symbol ('X' or 'O').
     */
    public char getGameStatus(){
        char checker;
        //checks every row
        for (int i = 0; i < boardSize; i++){
            if(board[i][0 ] != SYMBOL_BLANK){
                checker = board[i][0];
                for(int j = 0; j < boardSize; j++){
                    if(board[i][j] != checker){
                        break;
                    }
                    if(j == boardSize-1){
                        return checker;}
                }
            }
        }
        //checks every column
        for(int i = 0;  i < boardSize; i++){
            if(board[0 ][i] != SYMBOL_BLANK){
                checker = board[0][i];
                for(int j = 0; j < boardSize; j++){
                    if(board[j][i] != checker){
                        break;
                    }
                    if(j == boardSize-1){
                        return checker;}
                }
            }
        }
        //checks forwards diagonal
        if(board[0][0] != SYMBOL_BLANK){
            checker = board[0][0];
            int i = 0;
            int j = 0;
            while(i < boardSize){
                if(board[i][j] != checker){
                    break;
                }
                if(i == boardSize-1){
                    return checker;
                }
                i = i+1;
                j = j+1;
            }}
        //checks backwards diagonal
        if(board[0][boardSize-1] != SYMBOL_BLANK){
            checker = board[0][boardSize-1];
            int i = 0;
            int j = boardSize-1;
            while(i < boardSize){
                if(board[i][j] != checker){
                    break;
                }
                if(i == boardSize-1){
                    return checker;
                }
                i = i+1;
                j = j-1;
            }}
        //checks for a tie
        for(int i = 0; i < boardSize; i++){
            for(int j = 0; j < boardSize; j++){
                if(board[i][j] == SYMBOL_BLANK){
                    return '?';}
            }}
        return 'T';
    }

    /**
     * resets the game state so we can play again.
     */
    protected void resetGame(){
        for (int i = 0; i < board.length; i++){
            for( int j = 0; j<board[i].length; j++){
                board[i][j] = SYMBOL_BLANK;
            }
        }
    }

    /**
     * Creates a textual representation of the game board in the format:
     * @return A String representing the game board in the aforementioned format.
     */
    public String toString(){
        char letter = 65;
        String result = "";
        result += ("\n   ");
        for (int j=1; j<=boardSize; j++){
            result += (j + "    ");
        }

        for (int i=0; i<boardSize; i++){
            result += ("\n" +letter);
            letter++;
            for (int j=0; j<boardSize; j++){
                if (j!=boardSize-1 )
                    result += "  " + board[i][j] + " |";
                if (j == boardSize -1)
                    result += " " + board[i][j];
            }
            for (int j=0; j<boardSize; j++){
                if (i != boardSize-1 && j==0){
                    result+= "\n  ---|";
                }
                else if ((i!=boardSize-1) && (j == boardSize-1)){
                    result+= "---";
                }
                else if (i != boardSize-1 && j!=0){
                    result+= "----|";
                }

            }
        } 
        return result;
    }

    /**
     * Plays a single game of Tic-tac-toe by having players pick moves in turn. The first player to play is choosen uniformly at random.
     * @return A character representing the game's result: 'H' if the human player won, 'C' if the CPU won, 'T' if there was a tie, or 'Q' if the human quit the game.
     */
    public char playSingleGame(){
         GameStats gamestat= new GameStats();
        System.out.print(this);
        int x= (int)(Math.random()*2);
        if (x==0){
            symbol = SYMBOL_HUMAN;
            System.out.println("you go first");
        }
        else {
            symbol = SYMBOL_CPU;
        }
        Move gameMove = players[x].pickMove();
        this.executeMove(gameMove, symbol);
        System.out.println(this);
        while (this.getGameStatus()== '?' ){
            if (x==0){
                x=1;
                symbol= SYMBOL_CPU;
            }
            else{
                x=0;
                symbol= SYMBOL_HUMAN;
            }
            gameMove =  players[x].pickMove();
            if (gameMove!=null){
                this.executeMove(gameMove, symbol);
                System.out.println(players[x].game.toString());
            }
            else {
                return 'Q';
            }

            
        }
        return getGameStatus();

    }
    /** 
     * Runs consecutive Tic-tac-toe games until the user gets tired and quits. When the user quits, the win-loss-tie statistics are printed.
     **/
    public static void main(String[] args){
        System.out.println("welcome to Saumyas tic tac toe!! Please input boardSize as a number between 1-9.");
        
        Scanner scanner = new Scanner(System.in);
        int size = scanner.nextInt();
        if (size<0 || size>10){
            size=3;
        }

        Game game = new Game(size);
        game.players[0] = new HumanPlayer(game, 'X');
        game.players[1] = new CpuPlayer(game, 'O');
        GameStats gamestat= new GameStats();
        

        char gameStatus = '?';

        while (gameStatus != 'Q'){
            if (gameStatus=='?'){
                gameStatus=game.playSingleGame();
                
            }
            else if (gameStatus== 'T'){
                gamestat.recordTie();
                System.out.println("the game is a tie");
                System.out.println(gamestat);
                game.resetGame();
                gameStatus='?';
                
            }
            else if (gameStatus== 'X'){
                System.out.println("you won the game");
                gamestat.recordWin();
                System.out.println(gamestat);
                game.resetGame();
                gameStatus='?';
                
            }
            else if (gameStatus== 'O'){
                System.out.println("you lost the game");
                gamestat.recordLoss();
                System.out.println(gamestat);
                game.resetGame();
                gameStatus='?';
            }
                
                
            }
        

        System.out.println("Game quit");
    }
}

